
import DayPack from './DayPack.json'
import BackShader from './back_shader.js'

export default {
    id: 'DaySkin',
    colors: DayPack,
    shaders: [BackShader]
}
